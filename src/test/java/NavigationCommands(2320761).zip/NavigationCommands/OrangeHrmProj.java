package NavigationCommands;

import java.awt.AWTException;
import java.io.File;
import java.time.Duration;
 
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import orangeHrm.apachiePoi;
import orangeHrm.orange;
import orangeHrm.screenShot;

public class OrangeHrmProj {

	public static void main(String[] args) throws InterruptedException, AWTException {
        WebDriver driver = BasicClass.createDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
 
        
        try {
            // Launch the browser and open Google
            driver.get("https://google.com");
            driver.manage().window().maximize();
            driver.manage().deleteAllCookies();
            // Enter search term and submit
            WebElement input = driver.findElement(By.id("APjFqb"));
            input.sendKeys("Orange HRM demo");
            input.sendKeys(Keys.ENTER);
 
            // Verify search results page
            System.out.println(driver.getTitle());
            if (driver.getTitle().contains("Orange HRM demo")) {
                System.out.println("Search results for 'Orange HRM demo' displayed");
            } else {
                System.out.println("Unexpected page title: " + driver.getTitle());
            }
 
            // Navigate back and verify Google page
            driver.navigate().back();
            if (driver.getTitle().contains("Google")) {
                System.out.println("Back to Google page successful");
            } else {
                System.out.println("Unexpected URL after back: " + driver.getCurrentUrl());
            }
 
            // Navigate forward and verify search results page
            driver.navigate().forward();
            if (driver.getTitle().contains("Orange HRM demo")) {
                System.out.println("Forward to search results successful");
            } else {
                System.out.println("Unexpected page title after forward: " + driver.getTitle());
            }
 
            // Open OrangeHRM in a new tab
            driver.switchTo().newWindow(WindowType.TAB);
            driver.navigate().to("https://www.orangehrm.com/");
 
            // Capture the URL of the OrangeHRM page before closing
            String initialUrlAfterHrm = driver.getCurrentUrl();
 
            // Fill out and submit contact form
            driver.findElement(By.linkText("Contact Sales")).click();
            
            driver.findElement(By.id("Form_getForm_FullName")).sendKeys(ExcelUtils.getExcelValue(1, 0));
            driver.findElement(By.id("Form_getForm_Contact")).sendKeys(ExcelUtils.getExcelValue(1, 1));
            driver.findElement(By.id("Form_getForm_Email")).sendKeys(ExcelUtils.getExcelValue(1, 2));
            driver.findElement(By.id("Form_getForm_JobTitle")).sendKeys(ExcelUtils.getExcelValue(1, 3));

            WebElement countries = driver.findElement(By.id("Form_getForm_Country"));
            Select select = new Select(countries);
            select.selectByValue(ExcelUtils.getExcelValue(1, 4));

            WebElement employees = driver.findElement(By.id("Form_getForm_NoOfEmployees"));
            Select drop = new Select(employees);
            drop.selectByVisibleText(ExcelUtils.getExcelValue(1, 5));
            
            JavascriptExecutor js = (JavascriptExecutor) driver;
            WebElement textarea = driver.findElement(By.id("Form_getForm_Comment"));
            js.executeScript("arguments[0]. scrollIntoView();", textarea);
            Thread.sleep(1000); //for movement of scroller
       
            driver.findElement(By.id("Nocaptcha-Form_getForm_Captcha")).click();
    		
    		Thread.sleep(60000);
            driver.findElement(By.id("Form_getForm_action_submitForm")).click();
            
            //screenShot.getScreenshot(driver,js);
            //scrolling for better view
            WebElement view=driver.findElement(By.id("Form_getForm_Email"));
            js.executeScript("arguments[0]. scrollIntoView();", view);
            Thread.sleep(1000);  //used for taking screenshot perfect
            
            //To capture the Screenshot
            TakesScreenshot ts=(TakesScreenshot)driver;
            File sourceFile=ts.getScreenshotAs(OutputType.FILE);
            File targetFile=new File(System.getProperty("user.dir")+"\\Screenshot\\ss11.png");
            sourceFile.renameTo(targetFile);
          
            
            driver.findElement(By.id("Form_getForm_Comment")).sendKeys(ExcelUtils.getExcelValue(1, 6));
            
            driver.findElement(By.id("Nocaptcha-Form_getForm_Captcha")).click();
            driver.findElement(By.id("Form_getForm_action_submitForm")).click();
           
            // Close the current tab (OrangeHRM)
            driver.close();
            driver.switchTo().window(driver.getWindowHandles().iterator().next());
            // Verify navigation back to the Google search results tab
            if (driver.getCurrentUrl().equals(initialUrlAfterHrm)) {
                System.out.println("Unexpected URL after closing HRM tab: " + driver.getCurrentUrl());
            } else {
                System.out.println("Closed OrangeHRM tab and navigated back to search results");
            }
 
            // Close the browser
            driver.quit();
            System.out.println("Test Completed");
          } catch (NoSuchElementException e) {
        System.out.println("Element not found: " + e.getMessage());
       } catch (Exception e) {
        System.out.println("An error occurred: " + e.getMessage());
       } finally {
        if (driver != null) {
            driver.quit();
        }
    }
    }
}

